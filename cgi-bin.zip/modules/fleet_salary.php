<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
$db = getDB();
requirePerm('fleet_salary', 'view');

$db->query("CREATE TABLE IF NOT EXISTS fleet_driver_salary (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    driver_id       INT NOT NULL,
    salary_month    VARCHAR(7) NOT NULL,
    basic_salary    DECIMAL(10,2) DEFAULT 0,
    trip_count      INT DEFAULT 0,
    total_advance   DECIMAL(10,2) DEFAULT 0,
    other_deductions DECIMAL(10,2) DEFAULT 0,
    other_allowances DECIMAL(10,2) DEFAULT 0,
    deduction_notes TEXT,
    allowance_notes TEXT,
    net_payable     DECIMAL(10,2) DEFAULT 0,
    paid_amount     DECIMAL(10,2) DEFAULT 0,
    payment_date    DATE DEFAULT NULL,
    payment_mode    VARCHAR(40) DEFAULT 'Cash',
    reference_no    VARCHAR(80),
    status          ENUM('Draft','Paid') DEFAULT 'Draft',
    remarks         TEXT,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_driver_month (driver_id, salary_month)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$action = $_GET['action'] ?? 'list';
$id     = (int)($_GET['id'] ?? 0);

/* ── Delete ── */
if (isset($_GET['delete']) && isAdmin()) {
    $db->query("DELETE FROM fleet_driver_salary WHERE id=".(int)$_GET['delete']." AND status='Draft'");
    showAlert('success','Salary record deleted.');
    redirect('fleet_salary.php');
}

/* ── Save ── */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_salary'])) {
    requirePerm('fleet_salary', $id > 0 ? 'update' : 'create');
    $drv_id  = (int)$_POST['driver_id'];
    $month   = sanitize($_POST['salary_month']);
    $basic   = (float)$_POST['basic_salary'];
    $advance = (float)($_POST['total_advance'] ?? 0);
    $ded     = (float)($_POST['other_deductions'] ?? 0);
    $allow   = (float)($_POST['other_allowances'] ?? 0);
    $ded_n   = sanitize($_POST['deduction_notes'] ?? '');
    $allow_n = sanitize($_POST['allowance_notes'] ?? '');
    $net     = $basic + $allow - $advance - $ded;
    $paid    = (float)($_POST['paid_amount'] ?? 0);
    $pdate   = sanitize($_POST['payment_date'] ?? '');
    $pmode   = sanitize($_POST['payment_mode'] ?? 'Cash');
    $pref    = sanitize($_POST['reference_no'] ?? '');
    $status  = sanitize($_POST['status'] ?? 'Draft');
    $remarks = sanitize($_POST['remarks'] ?? '');
    $pdate_sql = $pdate ? "'$pdate'" : 'NULL';

    // Count trips for this driver in this month
    $trip_count = $db->query("SELECT COUNT(*) c FROM fleet_trips WHERE driver_id=$drv_id AND DATE_FORMAT(trip_date,'%Y-%m')='$month' AND status='Completed'")->fetch_assoc()['c'] ?? 0;
    // Auto-fetch advances from trips
    $trip_advance = $db->query("SELECT COALESCE(SUM(driver_advance),0) s FROM fleet_trips WHERE driver_id=$drv_id AND DATE_FORMAT(trip_date,'%Y-%m')='$month'")->fetch_assoc()['s'] ?? 0;

    if ($id > 0) {
        $db->query("UPDATE fleet_driver_salary SET driver_id=$drv_id, salary_month='$month',
            basic_salary=$basic, trip_count=$trip_count, total_advance=$trip_advance,
            other_deductions=$ded, other_allowances=$allow,
            deduction_notes='$ded_n', allowance_notes='$allow_n',
            net_payable=$net, paid_amount=$paid, payment_date=$pdate_sql,
            payment_mode='$pmode', reference_no='$pref', status='$status', remarks='$remarks'
            WHERE id=$id");
        showAlert('success','Salary updated.');
    } else {
        $check = $db->query("SELECT id FROM fleet_driver_salary WHERE driver_id=$drv_id AND salary_month='$month' LIMIT 1")->fetch_assoc();
        if ($check) { showAlert('danger','Salary already exists for this driver and month.'); redirect('fleet_salary.php?action=add'); }
        $db->query("INSERT INTO fleet_driver_salary
            (driver_id,salary_month,basic_salary,trip_count,total_advance,other_deductions,other_allowances,
             deduction_notes,allowance_notes,net_payable,paid_amount,payment_date,payment_mode,reference_no,status,remarks)
            VALUES ($drv_id,'$month',$basic,$trip_count,$trip_advance,$ded,$allow,'$ded_n','$allow_n',
            $net,$paid,$pdate_sql,'$pmode','$pref','$status','$remarks')");
        showAlert('success','Salary record created.');
    }
    redirect('fleet_salary.php');
}

$drivers = $db->query("SELECT id,full_name,role,basic_salary FROM fleet_drivers WHERE status='Active' ORDER BY full_name")->fetch_all(MYSQLI_ASSOC);

include '../includes/header.php';
?>
<script>document.getElementById('page-title').innerHTML='<i class="bi bi-wallet2 me-2"></i>Driver Salary';</script>
<?php

/* ── LIST ── */
if ($action === 'list'):
$filter_mo  = sanitize($_GET['month'] ?? date('Y-m'));
$filter_drv = (int)($_GET['driver'] ?? 0);
$where = "WHERE s.salary_month='$filter_mo'";
if ($filter_drv) $where .= " AND s.driver_id=$filter_drv";

$records = $db->query("SELECT s.*, d.full_name, d.role
    FROM fleet_driver_salary s
    LEFT JOIN fleet_drivers d ON s.driver_id=d.id
    $where ORDER BY d.full_name")->fetch_all(MYSQLI_ASSOC);

$total_net  = array_sum(array_column($records,'net_payable'));
$total_paid = array_sum(array_column($records,'paid_amount'));
?>
<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
    <h5 class="mb-0 fw-bold">Driver Salary</h5>
    <?php if (canDo('fleet_salary','create')): ?>
    <a href="?action=add" class="btn btn-primary"><i class="bi bi-plus-circle me-1"></i>Add Salary Record</a>
    <?php endif; ?>
</div>

<!-- Filters -->
<div class="card mb-3">
<div class="card-body py-2">
<form method="GET" class="row g-2 align-items-end">
    <div class="col-6 col-md-3">
        <label class="form-label form-label-sm">Month</label>
        <input type="month" name="month" class="form-control form-control-sm" value="<?= $filter_mo ?>">
    </div>
    <div class="col-6 col-md-3">
        <label class="form-label form-label-sm">Driver</label>
        <select name="driver" class="form-select form-select-sm">
            <option value="">All Drivers</option>
            <?php foreach ($drivers as $d): ?>
            <option value="<?= $d['id'] ?>" <?= $filter_drv==$d['id']?'selected':'' ?>><?= htmlspecialchars($d['full_name']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="col-12 col-md-2">
        <button type="submit" class="btn btn-outline-primary btn-sm w-100"><i class="bi bi-funnel me-1"></i>Filter</button>
    </div>
</form>
</div>
</div>

<!-- Summary -->
<div class="row g-2 mb-3">
    <div class="col-6 col-md-3"><div class="card text-center p-2"><small class="text-muted">Records</small><div class="fw-bold fs-6"><?= count($records) ?></div></div></div>
    <div class="col-6 col-md-3"><div class="card text-center p-2"><small class="text-muted">Total Net Payable</small><div class="fw-bold fs-6 text-primary">₹<?= number_format($total_net,2) ?></div></div></div>
    <div class="col-6 col-md-3"><div class="card text-center p-2"><small class="text-muted">Total Paid</small><div class="fw-bold fs-6 text-success">₹<?= number_format($total_paid,2) ?></div></div></div>
    <div class="col-6 col-md-3"><div class="card text-center p-2"><small class="text-muted">Pending</small><div class="fw-bold fs-6 text-danger">₹<?= number_format($total_net-$total_paid,2) ?></div></div></div>
</div>

<div class="card">
<div class="card-body p-0">
<div class="table-responsive">
<table class="table table-hover datatable mb-0">
<thead><tr>
    <th>Driver</th><th>Role</th><th>Month</th><th class="text-end">Basic</th>
    <th class="text-end">Trips</th><th class="text-end">Advance</th>
    <th class="text-end">Deductions</th><th class="text-end">Allowances</th>
    <th class="text-end">Net Payable</th><th class="text-end">Paid</th>
    <th>Status</th><th>Actions</th>
</tr></thead>
<tbody>
<?php foreach ($records as $r): ?>
<tr>
    <td><strong><?= htmlspecialchars($r['full_name']) ?></strong></td>
    <td><span class="badge bg-secondary"><?= $r['role'] ?></span></td>
    <td><?= date('M Y', strtotime($r['salary_month'].'-01')) ?></td>
    <td class="text-end">₹<?= number_format($r['basic_salary'],0) ?></td>
    <td class="text-end"><?= $r['trip_count'] ?></td>
    <td class="text-end text-warning">₹<?= number_format($r['total_advance'],0) ?></td>
    <td class="text-end text-danger">₹<?= number_format($r['other_deductions'],0) ?></td>
    <td class="text-end text-success">₹<?= number_format($r['other_allowances'],0) ?></td>
    <td class="text-end fw-bold">₹<?= number_format($r['net_payable'],0) ?></td>
    <td class="text-end text-success">₹<?= number_format($r['paid_amount'],0) ?></td>
    <td><span class="badge bg-<?= $r['status']==='Paid'?'success':'warning text-dark' ?>"><?= $r['status'] ?></span></td>
    <td>
        <?php if (canDo('fleet_salary','update')): ?>
        <a href="?action=edit&id=<?= $r['id'] ?>" class="btn btn-action btn-outline-primary me-1"><i class="bi bi-pencil"></i></a>
        <?php endif; ?>
        <?php if (isAdmin() && $r['status']==='Draft'): ?>
        <a href="?delete=<?= $r['id'] ?>" onclick="return confirm('Delete salary record?')" class="btn btn-action btn-outline-danger"><i class="bi bi-trash"></i></a>
        <?php endif; ?>
    </td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div></div></div>

<?php
/* ── ADD/EDIT ── */
else:
$r = [];
if ($id > 0) $r = $db->query("SELECT * FROM fleet_driver_salary WHERE id=$id LIMIT 1")->fetch_assoc() ?? [];
?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0 fw-bold"><?= $id>0?'Edit':'Add' ?> Salary Record</h5>
    <a href="fleet_salary.php" class="btn btn-outline-secondary btn-sm"><i class="bi bi-arrow-left me-1"></i>Back</a>
</div>
<form method="POST">
<input type="hidden" name="save_salary" value="1">
<div class="row g-3">
<div class="col-12"><div class="card"><div class="card-header"><i class="bi bi-wallet2 me-2"></i>Salary Details</div>
<div class="card-body"><div class="row g-3">
    <div class="col-6 col-md-4">
        <label class="form-label fw-bold">Driver *</label>
        <select name="driver_id" class="form-select" required onchange="fillBasic(this)">
            <option value="">— Select Driver —</option>
            <?php foreach ($drivers as $d): ?>
            <option value="<?= $d['id'] ?>" data-salary="<?= $d['basic_salary'] ?>" <?= ($r['driver_id']??0)==$d['id']?'selected':'' ?>>
                <?= htmlspecialchars($d['full_name']) ?> (<?= $d['role'] ?>)
            </option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="col-6 col-md-2">
        <label class="form-label fw-bold">Month *</label>
        <input type="month" name="salary_month" class="form-control" value="<?= $r['salary_month']??date('Y-m') ?>" required>
    </div>
    <div class="col-6 col-md-2">
        <label class="form-label">Basic Salary (₹)</label>
        <input type="number" name="basic_salary" id="basicSalary" class="form-control" step="0.01" value="<?= $r['basic_salary']??'' ?>" onchange="calcNet()">
    </div>
    <div class="col-6 col-md-2">
        <label class="form-label">Trip Advances (₹) <small class="text-muted">auto</small></label>
        <input type="number" name="total_advance" id="totalAdvance" class="form-control" step="0.01" value="<?= $r['total_advance']??0 ?>" onchange="calcNet()">
    </div>
    <div class="col-6 col-md-2">
        <label class="form-label">Other Deductions (₹)</label>
        <input type="number" name="other_deductions" class="form-control" step="0.01" value="<?= $r['other_deductions']??0 ?>" onchange="calcNet()">
    </div>
    <div class="col-12 col-md-4">
        <label class="form-label">Deduction Notes</label>
        <input type="text" name="deduction_notes" class="form-control" value="<?= htmlspecialchars($r['deduction_notes']??'') ?>">
    </div>
    <div class="col-6 col-md-2">
        <label class="form-label">Other Allowances (₹)</label>
        <input type="number" name="other_allowances" class="form-control" step="0.01" value="<?= $r['other_allowances']??0 ?>" onchange="calcNet()">
    </div>
    <div class="col-12 col-md-4">
        <label class="form-label">Allowance Notes</label>
        <input type="text" name="allowance_notes" class="form-control" value="<?= htmlspecialchars($r['allowance_notes']??'') ?>">
    </div>
    <div class="col-12">
        <div class="p-3 rounded" style="background:#e5f5eb">
            <div class="row text-center g-2">
                <div class="col-6 col-md-3"><small class="text-muted">Basic</small><div class="fw-bold" id="dispBasic">₹0</div></div>
                <div class="col-6 col-md-3"><small class="text-muted">+ Allowances</small><div class="fw-bold text-success" id="dispAllow">₹0</div></div>
                <div class="col-6 col-md-3"><small class="text-muted">− Deductions & Advances</small><div class="fw-bold text-danger" id="dispDed">₹0</div></div>
                <div class="col-6 col-md-3"><small class="text-muted">Net Payable</small><div class="fw-bold fs-5 text-primary" id="dispNet">₹0</div></div>
            </div>
        </div>
    </div>
</div></div></div></div>

<div class="col-12"><div class="card"><div class="card-header"><i class="bi bi-cash-coin me-2"></i>Payment Details</div>
<div class="card-body"><div class="row g-3">
    <div class="col-6 col-md-2">
        <label class="form-label">Paid Amount (₹)</label>
        <input type="number" name="paid_amount" class="form-control" step="0.01" value="<?= $r['paid_amount']??0 ?>">
    </div>
    <div class="col-6 col-md-2">
        <label class="form-label">Payment Date</label>
        <input type="date" name="payment_date" class="form-control" value="<?= $r['payment_date']??'' ?>">
    </div>
    <div class="col-6 col-md-2">
        <label class="form-label">Payment Mode</label>
        <select name="payment_mode" class="form-select">
            <?php foreach (['Cash','NEFT','RTGS','UPI','Cheque'] as $m): ?>
            <option <?= ($r['payment_mode']??'Cash')===$m?'selected':'' ?>><?= $m ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="col-6 col-md-2">
        <label class="form-label">Reference No</label>
        <input type="text" name="reference_no" class="form-control" value="<?= htmlspecialchars($r['reference_no']??'') ?>">
    </div>
    <div class="col-6 col-md-2">
        <label class="form-label">Status</label>
        <select name="status" class="form-select">
            <option <?= ($r['status']??'Draft')==='Draft'?'selected':'' ?>>Draft</option>
            <option <?= ($r['status']??'')==='Paid'?'selected':'' ?>>Paid</option>
        </select>
    </div>
    <div class="col-12 col-md-4">
        <label class="form-label">Remarks</label>
        <input type="text" name="remarks" class="form-control" value="<?= htmlspecialchars($r['remarks']??'') ?>">
    </div>
</div></div></div></div>

<div class="col-12 text-end">
    <a href="fleet_salary.php" class="btn btn-outline-secondary me-2">Cancel</a>
    <button type="submit" class="btn btn-primary px-4"><i class="bi bi-check2 me-1"></i>Save</button>
</div>
</div>
</form>
<script>
var driverSalaries = {};
<?php foreach ($drivers as $d): ?>
driverSalaries[<?= $d['id'] ?>] = <?= $d['basic_salary'] ?>;
<?php endforeach; ?>
function fillBasic(sel) {
    var sid = parseInt(sel.value);
    if (driverSalaries[sid]) {
        document.getElementById('basicSalary').value = driverSalaries[sid];
        calcNet();
    }
}
function calcNet() {
    var basic = parseFloat(document.querySelector('[name=basic_salary]').value)||0;
    var adv   = parseFloat(document.querySelector('[name=total_advance]').value)||0;
    var ded   = parseFloat(document.querySelector('[name=other_deductions]').value)||0;
    var allow = parseFloat(document.querySelector('[name=other_allowances]').value)||0;
    var net   = basic + allow - adv - ded;
    document.getElementById('dispBasic').textContent = '₹'+basic.toFixed(0);
    document.getElementById('dispAllow').textContent = '₹'+allow.toFixed(0);
    document.getElementById('dispDed').textContent   = '₹'+(adv+ded).toFixed(0);
    document.getElementById('dispNet').textContent   = '₹'+net.toFixed(0);
}
calcNet();
</script>
<?php endif; ?>
<?php include '../includes/footer.php'; ?>
